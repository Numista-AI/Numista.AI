# Plan.v1 — Public "Catalog (in progress)" page on numista.ai

Status: DRAFT PLAN ONLY. Nothing is built or deployed. Drafted 3 Nov 2026 by Catalog Builder.
Decision behind it: Eric chose "(a) public on numista.ai now" (3 Nov 2026, 8:52 AM ET).
Route before anything ships: **AG drafts → Argon review → CoS score 95+ → SAG → Eric's typed YES → EXECUTE.**
Never touch the live site or main. All work happens on a preview branch built on the **p7 preview**.

---

## 0. The five 26 Nov must-ships come first
Pricing tiers, scope line, soft-404, Meta pixel and Stripe come first. The catalog work can't take time, reviews or deploy slots away from them. Here's how that works:
- The catalog lives on its own branch and preview URL. It never merges until the five are live.
- The catalog soft-404 (Step 9) reuses the site soft-404 from the must-ship list. It doesn't build a second one.
- If any must-ship slips, catalog work pauses.

## 1. Data the page uses (read-only)
| File | What it holds |
|---|---|
| `/workspace/catalog-preview/schema.json` | Entry format (NAC1 code, type, year, mintage, sources, images, social posts) |
| `entries_20261103.jsonl` | 531 entries: 376 coins, 99 notes, 56 medals. 170 have an image. 13 were published on X. 220 are flagged for fact check |
| `entries_seed_20261103.jsonl` | **Present.** 2,612 entries (2,530 coins, 82 notes, 0 medals), with no images. All are collection-derived: 1,724 COLLECTION_DERIVED_DRAFT and 888 PLACEHOLDER_NAME_ONLY |
| `images_MANIFEST.csv` | 171 image rows with license, credit, source and sha256 |
| `COVERAGE.md`, `SEED_REPORT_20261103.md` | Gaps and counts |
| `/workspace/catalog-handoff/published_x_posts.csv` | Published Numista.Ai X posts, linked to entries |
Combined total: **3,143 entries.**

## 2. Steps (in order)
1. **Start from p7.** Branch from the p7 preview (latest is `/workspace/p7v12`, gate rules in `p7gate` / `baton_rules_p7.txt`). Don't start from main.
2. **Build the public export (the PII strip).** A script reads both entry files and writes one public file. It keeps only an allow-list of fields and drops everything else (see Section 4).
3. **PII gate (blocks every later step).** This runs before anything goes public (see Section 5).
4. **"Needs source" flag.** Any figure with status NOT_YET_SOURCED gets the flag, and so does any record whose source is "collection-derived". The page shows "Needs source", never a guessed value. That currently covers all 3,143 records, because no mintage is sourced yet. The page invents nothing and fills no blanks.
5. **Page layout ("Catalog (in progress)").**
   - Morgan the owl goes front and center at the top, using `Morgan_Owl_NoBubble_2048.png` (found at `/workspace/numista-ux/morgan-first/v2/` and `/workspace/`).
   - A clear "in progress" line: "This catalog is being built in public. Some details still need a source."
   - Sections in this order:
     1. Newest entries
     2. Search (manual search plus "Ask Morgan")
     3. Browse
     4. Coverage by year
     5. "Missing something?"
6. **Newest entries.** The 12–24 most recently added or updated records. It needs a date field, which the entries don't have yet (see gaps). Until one exists, the file build date stands in.
7. **Browse.**
   - By type, in this order: Coins, then Notes, then Medals (medals always come after coins and notes).
   - By year or era, using the existing era buckets plus an "Undated" group (5 preview entries have no year).
   - **Pre-Federal badge** on every pre-1792 item (`pre_federal: true`). That's 8 in the preview (7 coins, 1 medal) and 1 note in the seed.
   - **Foreign Coins**: a separate section, kept off the US lists. Right now it will be empty, because every entry is US (NAC1.*.US). It shows "Coming soon" and doesn't fake any entries.
8. **Search.**
   - Manual: search by name, year, denomination, series, designer and NAC code. It runs only on the public export, in the browser or on a static index.
   - Morgan AI search: Morgan answers only from the public export, cites the entry, and says "not yet sourced" rather than guessing. It has no access to collection data.
9. **Soft-404.** An unknown `/catalog/...` URL gets a friendly page: "We don't have that one yet." It offers search, Morgan, and a link to "Missing something?". It returns a real 404 status, so search engines don't index it.
10. **Coverage by year.** A year-by-year grid or bar chart showing counts by type (coin, note, medal) and how many have an image and a source. It's built from the numbers in the data only.
11. **"Missing something?" form.**
    - Fields: what's missing, plus optional year, type and source link. It asks for no name, collection details, values or photos of the user's own items.
    - A reply email is optional, kept privately, and never shown publicly.
    - Spam protection and a rate limit.
    - Submissions land in a review queue and never auto-publish.
12. **Image ranking.**
    - Order: museum first (NNC/Smithsonian, ANS, Met, BnF), then public domain (Wikimedia and others), then verified uploads.
    - Shown only with license and credit from the manifest.
    - No collection images, ever: they're user-scoped or AI-generated.
    - If there's no image, show a neutral placeholder.
13. **Large-text design for older users.**
    - Base text 20px or larger, high contrast (WCAG AA or better), and big tap targets (48px or larger).
    - Plain labels, nothing that only works on hover, and it works at 200% zoom.
14. **Look and feel with UX Designer.** Share the p7-based mockups with UX Designer before AG finishes the build plan, and agree on the Morgan placement, type scale, badges and the empty Foreign Coins state. Their sign-off goes into the Argon packet.
15. **Review route.** AG drafts, then Argon, then CoS 95+, then SAG, then Eric's typed YES. Only then EXECUTE, which means deploy to the preview first, then public.

## 3. Things the page must NOT claim
- No mintage, weight or fineness figure without a primary source. Today none are sourced.
- No "Mint-verified" label on collection-derived records.
- Known shaky claims from X are left out or flagged: the Fugio source file, the Chain cent grounding, the 1793 half-cent "first" claim, and the 1795 $10 placeholder link.

## 4. PII and internal fields to strip
**Scan result (3 Nov):** I found no user names, values, counts, ownership, receipts or personal notes in either entry file. The seed build had already dropped those. Keyword hits were benign:
- "Eric" appears only inside "Am**eric**an".
- "address" appears in "Gettysburg Address" and in note design text.
- "my" appears in a St. Christopher medal legend ("MY PROTECTOR").
- "user" appears in the seed's `image_status` text.

Some fields still have to be stripped from the public export, because they expose internal or private-collection details:
- `primary_image.local_path`, `primary_image.local_manifest`: box file paths
- `reused_from`: internal workspace paths
- `image_status` (seed): mentions "user-scoped GCS" collection images, so it's replaced with a neutral "No image yet"
- `seed_type: "collection-seed"`, `record_status` values COLLECTION_DERIVED_DRAFT / PLACEHOLDER_NAME_ONLY, and the source label "collection-derived": replaced with a public "Needs source" flag that doesn't mention a collection
- `proposal_status`, internal `figures.*.doc_id` / `method` / `grounding_score`, and `product_code`: internal only, so drop them
- `social_posts[].note`, `sources[].note`: keep only after a manual read

Rule: **allow-list, not block-list.** Only the fields listed for display get published. Any new field is dropped by default.

## 5. PII gate (it has to pass before anything goes public)
1. **Automated scan of all 3,143 records** in the public export. It must find zero of each of these:
   - emails
   - phone numbers
   - street addresses (excluding a list of known design text)
   - $ amounts or values
   - quantity, count, cost or purchase keys
   - grade, cert, storage, receipt or invoice keys
   - personal names from a private list of owner names, held off the repo
   - gs://, googleapis, users/ and /workspace paths
   - any field not on the allow-list
2. **Manual sample check.** A person reviews 100 random records (at least 50 from the seed), plus every record with an image or a history paragraph. They confirm zero user names, values, counts, ownership, receipts or notes.
3. Both results get saved to `/workspace/catalog-builder/PII_GATE_<date>.md`. Any hit is a FAIL, and the build stops until it's fixed and the gate runs again.

## 6. Test checklist
- [ ] The preview branch is built on p7, and main and live are untouched.
- [ ] The PII gate passes: automated scan 0/3,143 and manual sample 0 hits.
- [ ] The public export has only allow-listed fields.
- [ ] Every record with a NOT_YET_SOURCED or collection-derived value shows "Needs source", with no number made up.
- [ ] Counts on the page match the data: 3,143 total, Coins/Notes/Medals 2,906/181/56.
- [ ] Medals appear after Coins and Notes everywhere.
- [ ] The Pre-Federal badge is on all 9 pre-1792 items and on nothing after 1792.
- [ ] The Foreign Coins section is separate, with its empty state showing.
- [ ] Image order is museum, then public domain, then verified uploads. Every image shows its license and credit, and no collection images appear.
- [ ] Morgan owl (NoBubble 2048) is at the top center and looks sharp on mobile and desktop.
- [ ] Manual search finds items by name, year, NAC code and denomination.
- [ ] Morgan search cites its entries and says "not yet sourced" when it should.
- [ ] Unknown `/catalog/xyz` URLs show the soft-404 with a 404 status.
- [ ] The "Missing something?" form submits to a queue, and email is optional and never shown.
- [ ] The newest-entries section shows the correct latest items.
- [ ] Coverage by year matches the counts in the data.
- [ ] Large text works at 20px and 200% zoom, contrast is AA, and Lighthouse accessibility scores 95 or higher.
- [ ] Page speed holds up with 3,143 entries (paged or virtual list).
- [ ] UX Designer has signed off.
- [ ] None of the five 26 Nov must-ships was delayed or changed.

## 7. What could fail
- **PII leak through free text** (history, notes, design text). Mitigations: the allow-list plus the manual sample. A private owner-name list keeps the scan from depending on guesses.
- **The seed looks like a private collection.** Most of the 2,612 seed records are 2000–2026 coins. Publishing them could hint at what one person owns. Mitigations: never label them "collection", mix them into general type lists, and consider holding back placeholder-only records (888). **Eric decides.**
- **A page full of "Needs source"** looks unfinished, because 0 mintages are sourced. Mitigations: a clear "in progress" message, and putting records with sources and images first.
- **Morgan gives a wrong answer.** Mitigations: answers come only from the public export, every answer cites an entry, and Morgan refuses when there's no record.
- **Image license errors.** Mitigations: show only manifest rows with a license, check sha256, and hold back anything unclear.
- **Form spam or abuse.** Mitigations: rate limit, captcha, and a review queue.
- **Schedule creep onto the 26 Nov must-ships.** Mitigations: a separate branch and the pause rule in Section 0.
- **Soft-404 returns 200** and search engines index junk pages. The test checks the status code.
- **The NAC code pattern in schema.json** doesn't match seed codes like `...BEP.BASE.2`. Validate both files and fix the schema before building URLs.

## 8. Data gaps (reported, not filled)
- Mintage, weight and fineness: 0 sourced out of 3,143.
- Seed: 0 images, 0 medals, and all records are collection-derived (888 are name-only placeholders).
- Notes in the preview have no images.
- Foreign coins: 0 entries.
- Pre-Federal state coppers are missing. Fugio is the only Pre-Federal coin in the original set.
- There's no "date added" field, so the newest-entries section needs one.
- 5 preview entries are undated. Mint mark is unknown for most NNC-photo coins.
- Issues carried over from the X posts: the Fugio source, the Chain cent grounding, the 1793 half-cent claim, and the 1795 $10 link.

## Eric's decision (3 Nov 2026, 9:01 AM ET, via CoS) — BINDING
"Mix the modern coins into the full checklist and show placeholders marked details coming"
- 2000–2026 seed records appear ONLY inside the complete year-by-year checklist, interleaved with all other entries. They never appear as a standalone list, a "newest" list, or any list or filter that is labeled or sourced as seed or collection data.
- The newest-entries section must exclude seed records.
- The 888 placeholders show as name-only entries with the label "details coming". They have no images or figures, and nothing is invented.
- PII gate addition: confirm there's no seed or collection label in the UI, URLs, page source, or API responses.

## UX Designer review (3 Nov 2026, 9:02 AM ET) — OK WITH CHANGES, folded in (supersedes earlier layout order)
1. Order: top block is Morgan owl (160–200px) + one big search box (64px tall, 22px text, label "Search the catalog") + separate labeled button "Ask Morgan". Then Browse, Newest, Coverage by year, Missing something?
2. In-progress line: one sentence, calm neutral box (not warning/yellow), directly under search.
3. Pre-Federal badge: text pill, blue outline (brand owl blue) on white, dark navy text, 16px bold min, "Pre-Federal (before 1792)", 32px tall, not a tap target. Never color-only.
4. "Needs source": gray outline, #333 text on white, info "i" icon plus words; never red/orange. Once per card; detail view shows "Mintage: Needs source" beside blank figure.
5. "Details coming" (888 placeholders): same neutral pill; card = name + neutral coin-outline placeholder only. Never stack with Needs source.
6. Inside lists, sort entries with image+source first.
7. Coverage by year: chart plus "Show as table" toggle; word labels, not color alone.
8. Foreign coins empty state: one line "Foreign coins are coming later." No big empty panel.
9. Form: visible labels above fields, one primary "Send" button, confirmation "Thanks - we'll look into it.", email marked "(optional)".
10. Type scale: body 20px, card titles 24px, section headings 30px, page title 40px; tap targets 48px+, gaps 16px+; consistent top nav.
Test checklist additions: verify each item above at 200% zoom and on a phone width.

## UX mockups (signed off for Argon packet, 3 Nov 9:04 AM ET)
Files: /workspace/catalog-builder/ux/ (catalog_top_concept.html + PNGs, badges_concept.html/.png, README.md). Mockup data is example data only.
- Search button: filled navy (white on brand blue is only 6.4:1).
- Owl: NoBubble file has a square navy background; use a transparent-background or circular-crop version.
