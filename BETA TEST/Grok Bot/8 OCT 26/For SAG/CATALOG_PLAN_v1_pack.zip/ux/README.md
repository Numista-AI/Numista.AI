# Catalog (in progress) – UX concept mockups
CONCEPT only, not the live site. Example data only; no real values, personal info, photos or mintage numbers.

Files:
- catalog_top_concept.html, catalog_top_concept_1440.png, catalog_top_concept_1024.png – top block (nav, Morgan, title, search, in-progress note, 3 example cards)
- badges_concept.html, badges_concept.png – spec sheet for Pre-Federal, Needs source, Details coming
- morgan_owl.png – copy of Morgan_Owl_NoBubble_2048.png

Design rules: white background, no dark theme; navy #0B2545 headings, body #1A1A1A, brand blue #1F5FAD outlines; base text ≥20px (card titles 24px, page title 40px, search 22px); tap targets ≥48px (nav 52px, search/buttons 64px); every icon has a text label; no hover-only info; one tag per card; tags are labels, not tap targets; never color-only, never red/orange.

Contrast: #0B2545/#FFF 15.39 · #333/#FFF 12.63 · #1A1A1A/#FFF 17.40 · #1A1A1A/#F2F2F2 15.55 · #FFF/#0B2545 15.39 · #1F5FAD/#FFF 6.37 (outline) · #6B6B6B/#FFF 5.33 (outline).
